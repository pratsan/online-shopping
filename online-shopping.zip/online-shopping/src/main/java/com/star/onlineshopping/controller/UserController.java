/**
 * 
 */
package com.star.onlineshopping.controller;

/**
 * @author User1
 *
 */
public class UserController {

}
