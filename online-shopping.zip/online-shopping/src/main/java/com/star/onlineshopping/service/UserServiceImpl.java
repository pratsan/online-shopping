/**
 * 
 */
package com.star.onlineshopping.service;

/**
 * @author User1
 *
 */
public class UserServiceImpl {

}
