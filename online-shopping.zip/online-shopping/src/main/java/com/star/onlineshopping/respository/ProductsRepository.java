/**
 * 
 */
package com.star.onlineshopping.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.onlineshopping.entity.Products;

/**
 * @author User1
 *
 */
public interface ProductsRepository extends JpaRepository<Products, Long> {

}
