/**
 * 
 */
package com.star.onlineshopping.service;

/**
 * @author User1
 *
 */
public interface UserService {

}
