/**
 * 
 */
package com.star.onlineshopping.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.onlineshopping.entity.User;

/**
 * @author User1
 *
 */
public interface UserRepository extends JpaRepository<User, Long> {

}
