/**
 * 
 */
package com.star.onlineshopping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.star.onlineshopping.dto.UserReqDto;
import com.star.onlineshopping.dto.UserResDto;
import com.star.onlineshopping.exception.CredentialMissmatchException;
import com.star.onlineshopping.exception.UserExistException;
import com.star.onlineshopping.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService userService;

	@PostMapping("users/user")
	public ResponseEntity<UserResDto> userRegistration(@RequestBody UserReqDto userReqDto) throws UserExistException , CredentialMissmatchException {
		UserResDto userResDto = userService.userRegistration(userReqDto);
		return new ResponseEntity<>(userResDto, HttpStatus.OK);
	}

}
