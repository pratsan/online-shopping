/**
 * 
 */
package com.star.onlineshopping.dto;

/**
 * @author User1
 *
 */
public class UserResDto {
	
	private int statusCode;
	private String message;
	private String userName;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	

}
