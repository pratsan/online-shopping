/**
 * 
 */
package com.star.onlineshopping.utility;

/**
 * @author User1
 *
 */
public class ApplicationConstants {
	
	public static final String USER_EXIST="User already registered with this email, please give anothe email";
	public static final String USER_REGISTERED="User registered successfully,";
	public static final String CREDENTIAL_MISSMATCH="Password and ConfirmPassword are not matching, please provide same";



}
