/**
 * 
 */
package com.star.onlineshopping.exception;

/**
 * @author User1
 *
 */
public class RecordNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1747502351308293745L;

	public RecordNotFoundException(String message) {
		super(message);
	}

}
