/**
 * 
 */
package com.star.onlineshopping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.star.onlineshopping.dto.UserReqDto;
import com.star.onlineshopping.dto.UserResDto;
import com.star.onlineshopping.entity.User;
import com.star.onlineshopping.exception.CredentialMissmatchException;
import com.star.onlineshopping.exception.UserExistException;
import com.star.onlineshopping.respository.UserRepository;
import com.star.onlineshopping.utility.ApplicationConstants;

/**
 * @author Nagajyoti
 *
 */

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	@SuppressWarnings("unused")
	@Override
	public UserResDto userRegistration(UserReqDto userReqDto) throws UserExistException , CredentialMissmatchException {

		UserResDto userResDto = new UserResDto();
		User user;
		user = userRepository.findByEmailAndPhoneNumber(userReqDto.getEmail(),userReqDto.getPhoneNumber());


		if (!(user == null)) {

			throw new UserExistException(ApplicationConstants.USER_EXIST);
		} else {
            if(!(userReqDto.getPassword().equals(userReqDto.getConfirmPassword())))
            	throw new CredentialMissmatchException(ApplicationConstants.CREDENTIAL_MISSMATCH);
            user= new User();
            user.setConfirmPassword(userReqDto.getConfirmPassword());
            user.setPassword(userReqDto.getPassword());
            user.setEmail(userReqDto.getEmail());
            user.setPhoneNumber(userReqDto.getPhoneNumber());
            user.setName(userReqDto.getPhoneNumber());
            user.setUserType(userReqDto.getUserType());
			userRepository.save(user);
			userResDto.setStatusCode(HttpStatus.OK.value());
			userResDto.setMessage(
					ApplicationConstants.USER_REGISTERED + " " + userReqDto.getEmail() + " " + "Is your User Name");

		}
		return userResDto;

	}

}
