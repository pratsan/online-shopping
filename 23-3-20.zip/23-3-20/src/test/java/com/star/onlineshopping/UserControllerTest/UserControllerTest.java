/**
 * 
 */
package com.star.onlineshopping.UserControllerTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.star.onlineshopping.controller.UserController;
import com.star.onlineshopping.dto.UserReqDto;
import com.star.onlineshopping.dto.UserResDto;
import com.star.onlineshopping.exception.CredentialMissmatchException;
import com.star.onlineshopping.exception.UserExistException;
import com.star.onlineshopping.service.UserService;
import com.star.onlineshopping.utility.ApplicationConstants;

/**
 * @author User1
 *
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserControllerTest {
	
	@InjectMocks
	UserController userController;
	@Mock
	UserService userService;
	
	
	@Test
	public void userRegistration() throws UserExistException , CredentialMissmatchException  {
	UserReqDto userReqDto = new UserReqDto();
	userReqDto.setConfirmPassword("nagajyoti@123");
	userReqDto.setPassword("nagajyoti@123");
	userReqDto.setEmail("nagajyoti@gmail.com");
	userReqDto.setName("Nagajyoti");
	userReqDto.setUserType("Priority");
	userReqDto.setPhoneNumber("9980111546");

	UserResDto responseDto = new UserResDto();
	responseDto.setStatusCode(HttpStatus.OK.value());
	responseDto.setMessage(ApplicationConstants.USER_REGISTERED + " " + userReqDto.getEmail() + " " + "Is your User Name");

	Mockito.when(userService.userRegistration(userReqDto)).thenReturn(responseDto);
	ResponseEntity<UserResDto> result = userController.userRegistration(userReqDto);

	assertEquals(HttpStatus.OK, result.getStatusCode());

	}


}
