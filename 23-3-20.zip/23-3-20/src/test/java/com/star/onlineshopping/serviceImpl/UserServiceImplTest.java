/**
 * 
 */
package com.star.onlineshopping.serviceImpl;

import static org.junit.Assert.assertNotEquals;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;

import com.star.onlineshopping.controller.UserController;
import com.star.onlineshopping.dto.UserReqDto;
import com.star.onlineshopping.dto.UserResDto;
import com.star.onlineshopping.entity.User;
import com.star.onlineshopping.exception.CredentialMissmatchException;
import com.star.onlineshopping.exception.UserExistException;
import com.star.onlineshopping.respository.UserRepository;
import com.star.onlineshopping.service.UserService;

/**
 * @author User1
 *
 */
public class UserServiceImplTest {

	@InjectMocks
	UserController userController;
	@Mock
	UserService userService;

	@Mock
	UserRepository userRepository;

	@Test(expected = UserExistException.class)
	public void userRegistrationTest() throws UserExistException, CredentialMissmatchException {

		UserResDto res = new UserResDto();
		res.setStatusCode(HttpStatus.ALREADY_REPORTED.value());

		UserReqDto userReqDto = new UserReqDto();
		userReqDto.setConfirmPassword("nagajyoti@123");
		userReqDto.setPassword("nagajyoti@123");
		userReqDto.setEmail("nagajyoti@gmail.com");
		userReqDto.setName("Nagajyoti");
		userReqDto.setUserType("Priority");
		userReqDto.setPhoneNumber("9980111546");
		User user = new User();
		user.setConfirmPassword("nagajyoti@123");
		user.setPassword("nagajyoti@123");
		user.setEmail("nagajyoti@gmail.com");
		user.setPhoneNumber("9980111546");
		user.setName("Nagajyoti");
		user.setUserType("Priority");

		Mockito.when(userRepository.findByEmailAndPhoneNumber(userReqDto.getEmail(), userReqDto.getPhoneNumber()))
				.thenReturn(user);
		
		UserResDto userResDto = userService.userRegistration(userReqDto);
		assertNotEquals(res.getStatusCode(), userResDto.getStatusCode());

	}

	
	  
	
	  @Test(expected = CredentialMissmatchException.class) 
	  public void  userCredentialMissMatchTest() throws UserExistException, CredentialMissmatchException {
	  
	  UserResDto res = new UserResDto();
	  res.setStatusCode(HttpStatus.UNAUTHORIZED.value());
	  
	  UserReqDto userReqDto = new UserReqDto();
	  userReqDto.setConfirmPassword("nagajyoti@123");
	  userReqDto.setPassword("nagajyoti45@123");
	  userReqDto.setEmail("nagajyoti@gmail.com"); userReqDto.setName("Nagajyoti");
	  userReqDto.setUserType("Priority"); userReqDto.setPhoneNumber("9980111546");
	  
	  UserResDto result= userService.userRegistration(userReqDto);
	  assertNotEquals(res.getStatusCode(), result.getStatusCode());
	  
	  }
	  
      @Test
	  public void  userRegistrationSuccessTest() throws UserExistException, CredentialMissmatchException {
	  
	  UserResDto res = new UserResDto();
	  res.setStatusCode(HttpStatus.OK.value());
	  
	  UserReqDto userReqDto = new UserReqDto();
	  userReqDto.setConfirmPassword("nagajyoti@123");
	  userReqDto.setPassword("nagajyoti45@123");
	  userReqDto.setEmail("nagajyoti@gmail.com");
	  userReqDto.setName("Nagajyoti");
	  userReqDto.setUserType("Priority");
	  userReqDto.setPhoneNumber("9980111546");
	  
	  User user = new User();
		user.setConfirmPassword("nagajyoti@123");
		user.setPassword("nagajyoti@123");
		user.setEmail("nagajyoti@gmail.com");
		user.setPhoneNumber("9980111546");
		user.setName("Nagajyoti");
		user.setUserType("Priority");
		
		Mockito.when(userRepository.save(user))
		.thenReturn(user);
	  
	  UserResDto result= userService.userRegistration(userReqDto);
	  assertNotEquals(res.getStatusCode(), result.getStatusCode());
	  
	  }
	 

}
